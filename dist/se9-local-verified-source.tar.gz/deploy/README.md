# SE9 Demo Deployment

## 中文

这是当前 Demo 的设备部署说明。`device/se9-c/se9_file_api.c` 是运行在 Ubuntu 上的独立 C 文件服务，默认监听 `127.0.0.1:8443`；需要手机局域网直连时，将 `FILE_API_BIND_ADDR` 改为设备局域网地址或 `0.0.0.0`，并配合防火墙限制来源。部署配置从 `/etc/se9/se9-file-api.env` 读取，密码和设备密钥不得提交到仓库。Agent 当前只有 systemd 模板，安装 `/opt/se9/se9_agent` 后再启用该服务。

```bash
cmake -S device/se9-c -B build/se9-c
cmake --build build/se9-c
sudo useradd --system --home /var/lib/se9 --shell /usr/sbin/nologin se9
sudo install -d -o se9 -g se9 -m 0750 /vos/workspace/demo /var/lib/se9 /var/log/se9 /etc/se9
sudo install -m 0755 -o root -g root build/se9-c/se9_file_api /opt/se9/se9_file_api
sudo install -m 0640 -o root -g se9 deploy/se9-file-api.env.example /etc/se9/se9-file-api.env
# Edit /etc/se9/se9-file-api.env and replace the demo password.
sudo install -m 0644 -o root -g root deploy/se9-file-api.service /etc/systemd/system/se9-file-api.service
sudo install -m 0644 -o root -g root deploy/se9-logrotate /etc/logrotate.d/se9
sudo systemctl daemon-reload
sudo systemctl enable --now se9-file-api.service
```

更新程序时，先将新二进制写入临时文件并校验，再执行 `systemctl restart se9-file-api.service`；配置文件、`/var/lib/se9` 下的设备密钥和 `/vos/workspace` 文件不随二进制覆盖。Agent 安装完成后，复制并填写 `se9-agent.env.example`，安装 `se9-agent.service`，最后执行 `systemctl enable --now se9-agent.service`。

当前移动端 Demo：

```bash
cd mobile
flutter pub get
flutter run --dart-define=SE9_API=http://192.168.1.50:8443
```

## English

This is the device deployment note for the current demo. `device/se9-c/se9_file_api.c` is an independent C file service running on Ubuntu and listens on `127.0.0.1:8443` by default. For direct LAN access, set `FILE_API_BIND_ADDR` to the device LAN address or `0.0.0.0` and restrict the source network with the firewall. Runtime configuration is loaded from `/etc/se9/se9-file-api.env`; passwords and device keys must stay out of the repository. The Agent currently has a systemd template only; enable it after installing `/opt/se9/se9_agent`.

```bash
cmake -S device/se9-c -B build/se9-c
cmake --build build/se9-c
sudo useradd --system --home /var/lib/se9 --shell /usr/sbin/nologin se9
sudo install -d -o se9 -g se9 -m 0750 /vos/workspace/demo /var/lib/se9 /var/log/se9 /etc/se9
sudo install -m 0755 -o root -g root build/se9-c/se9_file_api /opt/se9/se9_file_api
sudo install -m 0640 -o root -g se9 deploy/se9-file-api.env.example /etc/se9/se9-file-api.env
# Edit /etc/se9/se9-file-api.env and replace the demo password.
sudo install -m 0644 -o root -g root deploy/se9-file-api.service /etc/systemd/system/se9-file-api.service
sudo install -m 0644 -o root -g root deploy/se9-logrotate /etc/logrotate.d/se9
sudo systemctl daemon-reload
sudo systemctl enable --now se9-file-api.service
```

For an upgrade, write and verify the new binary as a temporary file before running `systemctl restart se9-file-api.service`; do not overwrite the configuration, device keys under `/var/lib/se9`, or files under `/vos/workspace`. After installing the Agent, copy and fill in `se9-agent.env.example`, install `se9-agent.service`, and run `systemctl enable --now se9-agent.service`.

To run the current mobile demo:

```bash
cd mobile
flutter pub get
flutter run --dart-define=SE9_API=http://192.168.1.50:8443
```
