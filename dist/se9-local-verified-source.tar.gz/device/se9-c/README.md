# SE9 C Device Services

## 中文

SE9 端代码改为 C 实现。`se9_file_api.c` 使用 POSIX socket、线程和文件系统接口，默认监听 `127.0.0.1:8443`，也可以通过 `FILE_API_BIND_ADDR` 配置局域网监听地址，API 前缀统一为 `/api/v2`。当前 Demo 已实现按 `Content-Length` 分段读取 HTTP 请求、真实上传会话 ID、分片大小和数量校验、缺失分片/状态查询、临时上传目录、24 小时超时清理、SHA-256 完整文件校验、按请求路径原子落盘、健康检查、Demo 登录、目录列表、创建目录、文件下载和删除。`se9_agent.c` 已实现 `37020/udp` 的 `discover_request` 响应、设备 Ed25519 密钥持久化和响应签名、时间窗口与请求重放保护、X25519 临时握手、握手签名、AES-256-GCM 加密的 `pairing_result` 绑定字符串单播、云端 HTTP/HTTPS 注册和心跳，以及带设备 token 的 WSS Upgrade、TLS 主机名校验、Ping/Pong 和断线重连。Flutter 已实现发现响应和握手签名校验、X25519/AES-GCM 解密及云端绑定确认。CMake 通过 OpenSSL EVP 提供 SHA-256、Ed25519、X25519、AES-GCM 和 TLS。正式版本还需要补齐完整 JSON 解析、用户数据库、权限隔离、File API TLS、WSS 数据帧到本地 File API 的转发和持久化设备/会话存储。UDP 只传输发现、握手和绑定控制消息，不传输文件内容。

```bash
sudo apt-get install -y build-essential cmake libssl-dev
cmake -S device/se9-c -B build/se9-c
cmake --build build/se9-c
STORAGE_ROOT=/vos/workspace/demo DEMO_ADMIN_PASSWORD=change-me ./build/se9-c/se9_file_api
```

Go 文件服务仍保留为 API 原型和本地联调参考，不部署到 SE9。云端中继、用户管理和管理后台可以继续使用 Go；SE9 上的 File API 和 Agent 均使用 C。

## English

SE9-side code is now implemented in C. `se9_file_api.c` uses POSIX sockets, threads, and filesystem APIs, listens on `127.0.0.1:8443` by default, and supports a configurable LAN bind address through `FILE_API_BIND_ADDR`. The API prefix is consistently `/api/v2`. The current demo implements `Content-Length` based streaming HTTP reads, real upload-session IDs, chunk-size and chunk-count validation, missing-chunk/status queries, temporary upload directories, 24-hour expiry cleanup, full-file SHA-256 verification, atomic finalization at the requested path, health checks, demo login, directory listing, folder creation, file download, and deletion. CMake uses OpenSSL EVP for SHA-256. A production version still needs complete JSON parsing, a user database, permission isolation, TLS, the device Agent, and the relay protocol. LAN UDP discovery uses `37020/udp` for discovery and handshake control only; it never carries file contents.

```bash
sudo apt-get install -y build-essential cmake libssl-dev
cmake -S device/se9-c -B build/se9-c
cmake --build build/se9-c
STORAGE_ROOT=/vos/workspace/demo DEMO_ADMIN_PASSWORD=change-me ./build/se9-c/se9_file_api
```

The Go file service remains an API prototype and local integration reference and is not deployed to SE9. `se9_agent.c` responds to `discover_request` on `37020/udp`, persists an Ed25519 device key, signs discovery and handshake responses, rejects stale or replayed requests, performs an X25519 ephemeral handshake, sends an AES-256-GCM encrypted `pairing_result` claim payload by unicast, registers with the cloud and sends heartbeats over HTTP or verified HTTPS, and maintains a device-token-authenticated WSS connection with TLS hostname verification, Ping/Pong, and reconnects. Flutter verifies both signatures, decrypts the claim payload, and confirms the claim with the cloud. Production still needs complete JSON parsing, a user database, permission isolation, TLS for the local File API, WSS frame forwarding to the local File API, and persistent device/session storage. The cloud relay, user management, and admin services may continue in Go; the SE9 File API and Agent are written in C.
