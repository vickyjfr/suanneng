# SE9 Cloud Go Service

## 中文

阿里云服务器端使用 Go 实现，负责设备注册、在线状态和远程会话管理。SE9 设备端的 File API 与 Agent 使用 C，Flutter 负责移动端。

当前 Go 服务是云端控制面 Demo，包含：

- `/health` 健康检查；
- `POST /api/v2/devices/register` 设备注册；
- `POST /api/v2/devices/{id}/heartbeat` 设备心跳；
- `POST /api/v2/sessions` 创建远程会话（仅设备 owner 可用）。
- `POST /api/v2/devices/claim/confirm` 使用局域网交换的 64 位十六进制绑定字符串完成先到先得绑定。
- `/api/v2/auth/register`、`login`、`refresh`、`logout`；使用 bcrypt 密码哈希、短期 Access Token 和 Refresh Token；所有 JSON 控制面响应使用统一包络。
- Demo 将 Refresh Token 哈希持久化到 `AUTH_STATE_FILE`（默认 `./data/auth-refresh.json`）；Access Token 为 1 小时短期令牌，Refresh Token 轮换后旧令牌立即失效。
- 用户、设备 owner、设备 token 哈希和会话持久化到 `CLOUD_STATE_FILE`（默认 `./data/cloud-state.json`），使用临时文件原子替换。
- 配置 `TLS_CERT_FILE` 和 `TLS_KEY_FILE` 后，HTTP API 与 WebSocket Relay 统一通过 HTTPS/WSS 提供；未配置时仅适合本地 Demo。

App/Agent WebSocket 中继、设备 Token 校验和设备绑定确认已加入 Demo；数据库持久化、绑定字符串与设备端的云端可验证关联、TLS 终止和阿里云正式部署仍需继续实现。

```bash
go run ./cmd/cloud
```

## English

The Alibaba Cloud server is implemented in Go. It manages device registration, online status, and remote sessions. The SE9 File API and Agent are written in C, while Flutter is used for the mobile client.

The current Go service is a control-plane demo with:

- `/health` health check;
- `POST /api/v2/devices/register` device registration;
- `POST /api/v2/devices/{id}/heartbeat` device heartbeat;
- `POST /api/v2/sessions` remote session creation (owner only).
- `POST /api/v2/devices/claim/confirm` first-come device claiming with the 64-character hexadecimal claim string exchanged over LAN.
- `/api/v2/auth/register`, `login`, `refresh`, and `logout`, using bcrypt password hashes, short-lived access tokens, refresh-token rotation, and a common JSON envelope.
- The demo persists refresh-token hashes in `AUTH_STATE_FILE` (default `./data/auth-refresh.json`); access tokens last one hour and refresh-token rotation invalidates the previous token.
- Users, device ownership, device-token hashes, and sessions are persisted in `CLOUD_STATE_FILE` (default `./data/cloud-state.json`) using an atomic temporary-file replacement.
- When `TLS_CERT_FILE` and `TLS_KEY_FILE` are configured, both the HTTP API and WebSocket relay are served over HTTPS/WSS; without them the service is intended only for local demos.

App/Agent WebSocket relay, device-token validation, and claim confirmation are included in the demo; database persistence, a cloud-verifiable association between claim strings and device state, TLS termination, and production Alibaba Cloud deployment remain to be implemented.

```bash
go run ./cmd/cloud
```
